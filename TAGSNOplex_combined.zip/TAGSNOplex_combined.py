#!/usr/bin/env python3
"""TAGSNOplex: combined Chunk 1 + Chunk 2, no previous notebook cells needed.

Screens all supplied snoRNA/TAG sequences against transcript FASTA targets;
annotates 5'UTR/CDS/3'UTR and optionally adds shuffled-control statistics.
This is the transcriptome screen, not the separate three-gene CDS/residue tool.
"""
import os
import re
import json
import random
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

# ================= EDIT CONFIGURATION HERE =================
# Paths are relative to the folder from which you run this script/notebook.
BASE_DIR = Path.cwd()
FASTA_PATH = BASE_DIR / "input" / "target_transcripts.fasta"
SNO_LIST = BASE_DIR / "input" / "TAGsno_DBN.csv"
GTF_FILE = BASE_DIR / "input" / "gencode.v49.annotation.gtf"
OUT_DIR = BASE_DIR / "output" / "mrna_screen"
SNO_NAME_COLUMN = "gene_name"
SNO_SEQUENCE_COLUMN = "Sequence"

# RNAplex must be installed separately. Set a full path if it is not on PATH.
RNAplex_exec = "RNAplex"
RNAplex_path = BASE_DIR / "work" / "RNAplex"
RNAPLEX_TIMEOUT = 120

# Optional VARNA rendering only; not required for the screen.
vaRNA_path = BASE_DIR / "work" / "VARNA"
vaRNA_jar = BASE_DIR / "tools" / "VARNAv3-93.jar"

PLEX_L = 40
PLEX_C = 0  # Extension cost per nucleotide; NOT accessibility length.
# Set PLEX_C=55 only to reproduce the older extension-penalized runs.
ENERGY_MAX = -15.0  # Retained hits have deltaG strictly less than this value.
DUPLEX_MAXLEN = 150
DO_SHUFFLE_ZSCORE = True
N_SHUFFLES = 1000  # Use 25 for a quick check; minimum p then is 1/26.
SHUFFLE_SEED = 1
SAVE_SHUFFLE_LONG = True
N_TRANSCRIPTS_LIMIT = None  # e.g., 2 for a small initial run
REQUIRE_UTRS = True
TOL_FRAC = 0.0  # Exact exon/FASTA length match; use matching reference release.
DO_SITE_PIE = True
DO_TOP_PAIR_PIE = True
DEDUP_EXACT_SITES = False
allowed_regions = ["5'UTR", "CDS", "3'UTR"]


def clean_rna(raw):
    sequence = re.sub(r"\s+", "", str(raw)).upper().replace("T", "U")
    if not sequence or set(sequence) - set("ACGU"):
        raise ValueError("Query sequences must contain only A/C/G/T/U and whitespace.")
    return sequence


def validate_configuration():
    if (DO_SITE_PIE or DO_TOP_PAIR_PIE) and plt is None:
        raise ImportError("Install matplotlib for plots, or set both pie switches to False.")
    for path in (FASTA_PATH, SNO_LIST, GTF_FILE):
        if not Path(path).is_file():
            raise FileNotFoundError(f"Input not found: {path}")
    if not shutil.which(str(RNAplex_exec)):
        raise FileNotFoundError(f"RNAplex executable not found: {RNAplex_exec}")
    if DO_SHUFFLE_ZSCORE and N_SHUFFLES < 2:
        raise ValueError("N_SHUFFLES must be at least 2.")
    Path(OUT_DIR).mkdir(parents=True, exist_ok=True)
    Path(RNAplex_path).mkdir(parents=True, exist_ok=True)


def _parse_rnaplex_line(line):
    """
    Parse one non-header RNAplex result line.

    Expected RNAplex-style output often looks like:
        .(((((&))))).  10,22  :  5,17  (-14.50)

    This parser is intentionally tolerant:
      - extracts the dot-bracket-like first token
      - extracts the first two coordinate pairs
      - extracts the final parenthesized energy
    """
    line = line.strip()
    if not line or line.startswith(">"):
        return None

    parts = line.split()
    dbn = parts[0]

    coord_matches = re.findall(r"(\d+)\s*,\s*(\d+)", line)
    energy_matches = re.findall(r"\(\s*(-?\d+(?:\.\d+)?)\s*\)", line)

    if len(coord_matches) < 2 or not energy_matches:
        raise ValueError(f"Could not parse RNAplex output line: {line}")

    pos1_l, pos1_r = map(int, coord_matches[0])
    pos2_l, pos2_r = map(int, coord_matches[1])
    dG = float(energy_matches[-1])

    return pos1_l, pos1_r, pos2_l, pos2_r, dbn, dG


# --------------------------------------------------------------------
# RNAplex wrapper
# --------------------------------------------------------------------
def get_RNA_plex_output(
    seq1,
    seq2,
    l=40,
    c=0,
    return_energy=False,
    rnaplex_executable=RNAplex_exec,
    work_dir=RNAplex_path,
    keep_debug_files=False
):
    """
    Run RNAplex with seq2 as query and seq1 as target.

    Returns:
      pos1_l, pos1_r = target coordinates in seq1
      pos2_l, pos2_r = query coordinates in seq2
      dbn             = RNAplex dot-bracket interaction
      seq_total       = target_subseq + '&' + query_subseq
      dG              = deltaG if return_energy=True

    Notes:
      - RNAplex -l is maximum interaction length.
      - RNAplex -c is extension cost per nucleotide, NOT accessibility length.
      - For normal RNAplex energy-only screening, c=0 is the safer default.
      - To reproduce older TAGSNOplex runs that used c=55, pass c=55.
    """
    seq1 = str(seq1).upper().replace("T", "U")
    seq2 = str(seq2).upper().replace("T", "U")

    rnaplex_executable = str(rnaplex_executable)
    os.makedirs(work_dir, exist_ok=True)

    with tempfile.TemporaryDirectory(dir=work_dir) as tmpdir:
        tmpdir = Path(tmpdir)
        seq1_file = tmpdir / "seq1.fa"
        seq2_file = tmpdir / "seq2.fa"

        seq1_file.write_text(">seq1\n" + seq1 + "\n")
        seq2_file.write_text(">seq2\n" + seq2 + "\n")

        cmd = [
            rnaplex_executable,
            "-q", str(seq2_file),
            "-t", str(seq1_file),
            "-l", str(l),
        ]

        # Only pass -c if nonzero. RNAplex default is 0.
        if c is not None and float(c) != 0:
            cmd.extend(["-c", str(c)])

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=RNAPLEX_TIMEOUT
        )

        if result.returncode != 0:
            raise RuntimeError(
                "[RNAplex] non-zero exit code\n"
                f"Command: {' '.join(cmd)}\n"
                f"STDOUT:\n{result.stdout}\n"
                f"STDERR:\n{result.stderr}"
            )

        raw_output = result.stdout.strip()

        if keep_debug_files:
            debug_out = Path(work_dir) / "predict_result2.txt"
            debug_out.write_text(raw_output + "\n")

        if not raw_output:
            return [0, 0, 0, 0, "..", "AA", 0] if return_energy else [0, 0, 0, 0, "..", "AA"]

        # Find the last non-header result line.
        candidate_lines = [
            line.strip()
            for line in raw_output.splitlines()
            if line.strip() and not line.strip().startswith(">")
        ]

        if not candidate_lines:
            return [0, 0, 0, 0, "..", "AA", 0] if return_energy else [0, 0, 0, 0, "..", "AA"]

        x = candidate_lines[-1]

        try:
            parsed = _parse_rnaplex_line(x)
        except Exception as exc:
            raise ValueError(f"Unrecognized RNAplex output: {x}") from exc

        pos1_l, pos1_r, pos2_l, pos2_r, dbn, dG = parsed

        if not (1 <= pos1_l <= pos1_r <= len(seq1) and
                1 <= pos2_l <= pos2_r <= len(seq2)):
            raise ValueError(f"RNAplex coordinates outside input sequences: {x}")
        seq_l = seq1[pos1_l - 1:pos1_r]
        seq_R = seq2[pos2_l - 1:pos2_r]
        seq_total = seq_l + "&" + seq_R

        if return_energy:
            return pos1_l, pos1_r, pos2_l, pos2_r, dbn, seq_total, dG
        else:
            return pos1_l, pos1_r, pos2_l, pos2_r, dbn, seq_total



def get_highlight_details(coor_list, color_list_input="random"):
    rng = random.Random(1)
    colors = (["#%06X" % rng.randrange(0x1000000) for _ in coor_list]
              if color_list_input == "random" else color_list_input)
    if len(colors) != len(coor_list):
        raise ValueError("One highlight color is needed per interval.")
    return ";".join(f"{left}-{right}:fill={color}"
                    for (left, right), color in zip(coor_list, colors))


def show_structure(dbn, seq, name1, name2, rotation=20, suffix="structure",
                   res=2, arms="", coor_list=None, color_list_input="random"):
    """Render optional VARNA PNG; return its path. Java and VARNA required."""
    if not Path(vaRNA_jar).is_file():
        raise FileNotFoundError(f"Download VARNA and set vaRNA_jar: {vaRNA_jar}")
    output = Path(vaRNA_path) / "vaRNA_output" / f"{suffix}.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    command = ["java", "-cp", str(vaRNA_jar), "fr.orsay.lri.varna.applications.VARNAcmd",
               "-sequenceDBN", seq, "-structureDBN", dbn, "-algorithm", "radiate",
               "-bpStyle", "line", "-flat", "true", "-resolution", str(res),
               "-rotation", str(rotation), "-title", f"{name1}_{name2}_{arms}",
               "-titleSize", "10", "-o", str(output)]
    if coor_list:
        command += ["-highlightRegion", get_highlight_details(coor_list, color_list_input)]
    subprocess.run(command, check=True, capture_output=True, text=True,
                   timeout=RNAPLEX_TIMEOUT)
    if not output.is_file():
        raise RuntimeError(f"VARNA did not create {output}")
    try:
        from IPython.display import Image, display
        display(Image(filename=str(output)))
    except ImportError:
        print(output)
    return output

def parse_gtf(gtf_file):
    gtf = pd.read_csv(
        gtf_file,
        sep="\t",
        comment="#",
        header=None,
        names=["seqname", "source", "feature", "start", "end", "score", "strand", "frame", "attribute"]
    )

    gtf["feature_norm"] = gtf["feature"].astype(str).str.lower()

    keep_features = {"exon", "cds", "stop_codon", "five_prime_utr", "three_prime_utr", "utr"}
    gtf = gtf[gtf["feature_norm"].isin(keep_features)].copy()

    def rx(field, s):
        m = re.search(fr'{field} "([^"]+)"', str(s))
        return m.group(1) if m else None

    gtf["gene_id"] = gtf["attribute"].apply(lambda s: rx("gene_id", s))
    gtf["transcript_id_full"] = gtf["attribute"].apply(lambda s: rx("transcript_id", s))
    gtf["transcript_id"] = gtf["transcript_id_full"].apply(
        lambda x: x.split(".")[0] if isinstance(x, str) else x
    )

    gtf["length"] = (gtf["end"] - gtf["start"] + 1).astype(int)

    gtf["feature_label"] = gtf["feature_norm"].map({
        "exon": "EXON",
        "cds": "CDS",
        "stop_codon": "CDS",
        "five_prime_utr": "5'UTR",
        "three_prime_utr": "3'UTR",
        "utr": "UTR"
    })

    cols = [
        "seqname", "start", "end", "strand",
        "feature_norm", "feature_label",
        "transcript_id", "length"
    ]
    gtf = gtf[cols]

    print(
        f"[GTF] {len(gtf):,} rows kept (EXON/CDS/UTR); "
        f"{gtf['transcript_id'].nunique():,} transcripts with features."
    )

    return gtf


# --------------------------------------------------------------------
# 2) snoRNA list
# --------------------------------------------------------------------
def load_sno_list_df(path, name_col="gene_name", seq_col="Sequence"):
    if Path(path).suffix.lower() not in {".csv", ".xlsx", ".xls"}:
        raise ValueError("Export the sno-list as CSV or Excel; Apple Numbers files are not supported.")
    df = pd.read_csv(path) if str(path).lower().endswith(".csv") else pd.read_excel(path)
    df = df[[name_col, seq_col]].dropna()

    df["name"] = df[name_col].astype(str).str.strip()
    df["sequence"] = (
        df[seq_col]
        .astype(str)
        .str.strip()
        .str.upper()
        .str.replace("T", "U", regex=False)
    )

    df["sequence"] = df["sequence"].map(clean_rna)
    df = df.drop_duplicates(["name", "sequence"])
    if df.empty or df["name"].eq("").any() or df["name"].duplicated().any():
        raise ValueError("Sno-list is empty or contains blank/ambiguous names. Give domains unique names.")
    return df[["name", "sequence"]]


# --------------------------------------------------------------------
# 3) FASTA helpers
# --------------------------------------------------------------------
def parse_gencode_subset_fasta_headers(fasta_path):
    """
    Return {gene_symbol -> set(versionless ENSTs)} for either:
      - MANE-style headers:
          >ENST:ENST00000372285.8 | Gene:CD40 | UniProt:P25942 | CD40_HUMAN
      - GENCODE-style headers:
          >ENST00000335137.4|ENSG00000141510.20|...|TP53|...
    """
    gene_to_ensts = {}

    with open(fasta_path, "r") as fh:
        for line in fh:
            if not line.startswith(">"):
                continue

            raw = line[1:].strip()

            m_enst = re.search(r"ENST:([A-Z0-9]+(?:\.\d+)?)", raw)
            m_gene = re.search(r"Gene:([A-Za-z0-9_.-]+)", raw)

            if m_enst:
                enst_full = m_enst.group(1)
                enst_base = enst_full.split(".")[0]
                gene_symbol = m_gene.group(1) if m_gene else enst_base
            else:
                parts = raw.split("|")
                if not parts:
                    continue

                enst_base = parts[0].split(".", 1)[0]
                gene_symbol = parts[5].strip() if len(parts) >= 6 and parts[5] else enst_base

            gene_to_ensts.setdefault(gene_symbol, set()).add(enst_base)

    return gene_to_ensts


def load_transcript_sequence(fasta_path, transcript_id):
    """
    Pull full cDNA by ENST versionless match and convert T->U.
    """
    want = transcript_id.split(".")[0]
    take = False
    seq_lines = []

    with open(fasta_path, "r") as fh:
        for line in fh:
            if line.startswith(">"):
                if take and seq_lines:
                    break

                raw = line[1:].strip()

                m_enst = re.search(r"ENST:([A-Z0-9]+(?:\.\d+)?)", raw)
                if m_enst:
                    enst_base = m_enst.group(1).split(".")[0]
                else:
                    parts = raw.split("|")
                    enst_base = parts[0].split(".", 1)[0] if parts else ""

                take = (enst_base == want)
            else:
                if take:
                    seq_lines.append(line.strip())

    seq = "".join(seq_lines)

    if not seq:
        raise ValueError(f"Transcript {transcript_id} not found in FASTA: {fasta_path}")

    return seq.upper().replace("T", "U")


# --------------------------------------------------------------------
# 4) Transcript-space feature map helpers
# --------------------------------------------------------------------
def _merge_intervals(ivals):
    """Merge overlapping genomic intervals [(s,e), ...]."""
    if not ivals:
        return []

    ivals = sorted(ivals, key=lambda x: (x[0], x[1]))
    merged = [ivals[0]]

    for s, e in ivals[1:]:
        ps, pe = merged[-1]
        if s <= pe + 1:
            merged[-1] = (ps, max(pe, e))
        else:
            merged.append((s, e))

    return merged


def _split_exon_by_cds(exon_interval, cds_ivals):
    """
    Split one exon [s,e] by merged CDS intervals.
    Returns pieces as: (sub_s, sub_e, label), where label is CDS or UTR.
    """
    s, e = exon_interval
    out = []
    pos = s

    for cs, ce in cds_ivals:
        if ce < s or cs > e:
            continue

        if pos < cs:
            out.append((pos, min(e, cs - 1), "UTR"))

        out.append((max(pos, cs), min(e, ce), "CDS"))
        pos = ce + 1

        if pos > e:
            break

    if pos <= e:
        out.append((pos, e, "UTR"))

    out = [(a, b, t) for (a, b, t) in out if a <= b]
    return out


def build_cdna_map(gtf_df, transcript_id):
    """Build a strand-aware spliced map from exons and CDS + stop_codon.

    CDS region labels include the terminal stop codon. No codon/residue
    translation is performed by this transcriptome-screening workflow.
    Explicit UTR rows are not concatenated, avoiding gaps/double counting.
    """
    tx = transcript_id.split(".")[0]
    sub = gtf_df[gtf_df["transcript_id"] == tx]
    exons = sub[sub["feature_norm"] == "exon"].drop_duplicates(["start", "end"])
    cds = sub[sub["feature_norm"] == "cds"]
    if exons.empty or cds.empty:
        return None
    if sub["strand"].nunique() != 1 or sub["seqname"].nunique() != 1:
        raise ValueError(f"Ambiguous genomic location for {transcript_id}")
    strand = sub["strand"].iloc[0]
    if strand not in {"+", "-"}:
        raise ValueError(f"Invalid strand for {transcript_id}")
    exons = exons.sort_values(["start", "end"], ascending=(strand == "+"))
    genomic_coding = sub[sub["feature_norm"].isin(["cds", "stop_codon"])]
    coding = _merge_intervals([(int(r.start), int(r.end)) for r in genomic_coding.itertuples()])
    fmap = []
    position = 1
    for exon in exons.itertuples():
        pieces = _split_exon_by_cds((int(exon.start), int(exon.end)), coding)
        if strand == "-":
            pieces = pieces[::-1]
        for left, right, label in pieces:
            length = right - left + 1
            fmap.append({"start_cdna": position, "end_cdna": position + length - 1,
                         "feature": label})
            position += length
    coding_segments = [seg for seg in fmap if seg["feature"] == "CDS"]
    if not coding_segments:
        return None
    coding_start = min(seg["start_cdna"] for seg in coding_segments)
    coding_end = max(seg["end_cdna"] for seg in coding_segments)
    for seg in fmap:
        if seg["feature"] == "UTR":
            if seg["end_cdna"] < coding_start:
                seg["feature"] = "5'UTR"
            elif seg["start_cdna"] > coding_end:
                seg["feature"] = "3'UTR"
            else:
                raise ValueError(f"Noncoding segment within CDS for {transcript_id}")
    merged = []
    for seg in fmap:
        if merged and seg["feature"] == merged[-1]["feature"]:
            merged[-1]["end_cdna"] = seg["end_cdna"]
        else:
            merged.append(dict(seg))
    return merged


def classify_duplex_region(pos_l, pos_r, fmap):
    """
    Pick transcript region with largest overlap with target interval [pos_l, pos_r].
    """
    if not fmap or pos_l == 0 or pos_r == 0:
        return "unknown"

    best = "unknown"
    best_ov = 0

    for seg in fmap:
        a = max(pos_l, seg["start_cdna"])
        b = min(pos_r, seg["end_cdna"])

        if a <= b:
            ov = b - a + 1
            if ov > best_ov:
                best = seg["feature"]
                best_ov = ov

    return best


# --------------------------------------------------------------------
# 5) Audit transcript feature map
# --------------------------------------------------------------------
def audit_transcript(gtf_df, enst, seq_len, require_utrs=True, tol_frac=TOL_FRAC):
    fmap = build_cdna_map(gtf_df, enst)

    if not fmap:
        return {"ok": False, "reason": "no_map"}

    len_5 = sum(
        seg["end_cdna"] - seg["start_cdna"] + 1
        for seg in fmap
        if seg["feature"] == "5'UTR"
    )

    len_c = sum(
        seg["end_cdna"] - seg["start_cdna"] + 1
        for seg in fmap
        if seg["feature"] == "CDS"
    )

    len_3 = sum(
        seg["end_cdna"] - seg["start_cdna"] + 1
        for seg in fmap
        if seg["feature"] == "3'UTR"
    )

    feat_sum = len_5 + len_c + len_3

    have_5 = len_5 > 0
    have_3 = len_3 > 0

    ok_len = (
        seq_len > 0
        and abs(feat_sum - seq_len) <= max(0, int(tol_frac * seq_len))
    )

    ok_utrs = (not require_utrs) or (have_5 and have_3)

    return {
        "ok": bool(ok_len and ok_utrs),
        "reason": None if (ok_len and ok_utrs) else ("len_mismatch" if not ok_len else "missing_utr"),
        "len_seq": int(seq_len),
        "len_feat": int(feat_sum),
        "len_5": int(len_5),
        "len_cds": int(len_c),
        "len_3": int(len_3),
        "fmap": fmap
    }


# --------------------------------------------------------------------
# 6) Main RNAplex screen
# --------------------------------------------------------------------
def screen_sno_vs_targets_df_fast(
    sno_df,
    fasta_path,
    gtf_df,
    gene_to_ensts_override=None,
    n_transcripts_limit=None,
    l=40,
    c=0,
    energy_max=-12.0,
    duplex_maxlen=150,
    require_utrs=True,
    make_audit_csv=True
):
    gene_to_ensts = (parse_gencode_subset_fasta_headers(fasta_path)
                     if gene_to_ensts_override is None else gene_to_ensts_override)
    pairs = [
        (g, e)
        for g, ensts in sorted(gene_to_ensts.items())
        for e in sorted(ensts)
    ]

    if n_transcripts_limit:
        pairs = pairs[:int(n_transcripts_limit)]

    print(f"[TARGETS] Using {len(pairs)} transcript(s).")

    seq_cache = {}
    fmap_cache = {}
    results = []
    audit_skips = []

    for gene, enst in pairs:
        tx_seq = seq_cache.get(enst)

        if tx_seq is None:
            try:
                tx_seq = load_transcript_sequence(fasta_path, enst)
            except ValueError:
                audit_skips.append({
                    "gene": gene,
                    "enst": enst,
                    "reason": "no_fasta_seq"
                })
                continue

            seq_cache[enst] = tx_seq

        audit = audit_transcript(
            gtf_df,
            enst,
            len(tx_seq),
            require_utrs=require_utrs,
            tol_frac=TOL_FRAC
        )

        if not audit["ok"]:
            audit_skips.append({
                "gene": gene,
                "enst": enst,
                "reason": audit["reason"],
                "len_seq": audit.get("len_seq", np.nan),
                "len_feat": audit.get("len_feat", np.nan),
                "len_5": audit.get("len_5", np.nan),
                "len_cds": audit.get("len_cds", np.nan),
                "len_3": audit.get("len_3", np.nan)
            })
            continue

        fmap_cache[enst] = audit["fmap"]

        for _, sno in sno_df.iterrows():
            sname = sno["name"]
            sseq = sno["sequence"]

            try:
                (
                    pos1_l,
                    pos1_r,
                    pos2_l,
                    pos2_r,
                    dbn,
                    seq_total,
                    dG
                ) = get_RNA_plex_output(
                    tx_seq,
                    sseq,
                    l=l,
                    c=c,
                    return_energy=True
                )

                if pos1_l == 0 or pos1_r == 0:
                    keep = False
                    region = "no_hit"
                    dup_len = 0
                    duplex_dbn = ""
                    duplex_seq = ""
                else:
                    target_subseq = seq_total.split("&", 1)[0]
                    dup_len = len(target_subseq)

                    keep = (dG < energy_max) and (dup_len <= duplex_maxlen)
                    region = classify_duplex_region(pos1_l, pos1_r, fmap_cache[enst])

                    duplex_dbn = dbn
                    duplex_seq = seq_total

                results.append({
                    "snoRNA": sname,
                    "target_gene": gene,
                    "target_enst": enst,
                    "deltaG": dG,
                    "duplex_length": dup_len,
                    "target_region_label": region,
                    "pos1_l": pos1_l,
                    "pos1_r": pos1_r,
                    "pos2_l": pos2_l,
                    "pos2_r": pos2_r,
                    "pass_filters": bool(keep),
                    "duplex_dbn": duplex_dbn,
                    "duplex_seq": duplex_seq,
                    "len_seq": audit["len_seq"],
                    "len_feat": audit["len_feat"],
                    "len_5": audit["len_5"],
                    "len_cds": audit["len_cds"],
                    "len_3": audit["len_3"]
                })

            except Exception as e:
                results.append({
                    "snoRNA": sname,
                    "target_gene": gene,
                    "target_enst": enst,
                    "error": str(e),
                    "pass_filters": False,
                    "duplex_dbn": "",
                    "duplex_seq": ""
                })

    df = pd.DataFrame(results)

    if make_audit_csv and audit_skips:
        audit_csv = Path(OUT_DIR) / "audit_skips.csv"
        pd.DataFrame(audit_skips).to_csv(audit_csv, index=False)
        print(f"[AUDIT] Skipped {len(audit_skips)} transcript(s). See {audit_csv}")

    return df


# --------------------------------------------------------------------
# 7) Shuffled-control helpers
# --------------------------------------------------------------------
def shuffle_seq_mono(seq, rng, max_tries=25):
    """
    Mononucleotide-preserving shuffle.
    Preserves length and base composition.
    """
    seq = str(seq).upper().replace("T", "U")

    if len(seq) <= 1:
        return seq

    chars = list(seq)
    rng.shuffle(chars)
    return "".join(chars)


def add_shuffle_zscores_to_top_pairs(
    df_top_pair,
    sno_df,
    fasta_path,
    n_shuffles=100,
    l=40,
    c=0,
    seed=1,
    out_long_csv=None
):
    """
    For each observed top-pair hit:
      1) Shuffle the snoRNA/domain sequence n times.
      2) Rerun RNAplex against the same transcript.
      3) Compute background ΔG mean, SD, Z-score, and empirical p-value.

    Because more negative ΔG is stronger:
      shuffle_z = (observed_deltaG - mean(shuffled_deltaG)) / sd(shuffled_deltaG)

    Stronger-than-background hits usually have NEGATIVE Z-scores.

    Empirical p-value:
      fraction of shuffled controls with ΔG <= observed ΔG,
      using +1 smoothing.
    """
    if df_top_pair.empty:
        return df_top_pair

    sno_seq_by_name = dict(zip(sno_df["name"], sno_df["sequence"]))

    tx_seq_cache = {}
    stats_rows = []
    long_rows = []

    for i, row in df_top_pair.iterrows():
        sname = row["snoRNA"]
        enst = row["target_enst"]
        gene = row.get("target_gene", "")

        obs_dG = pd.to_numeric(row.get("deltaG", np.nan), errors="coerce")

        if pd.isna(obs_dG):
            stats_rows.append({
                "snoRNA": sname,
                "target_enst": enst,
                "shuffle_n": 0,
                "shuffle_failures": n_shuffles,
                "shuffle_deltaG_mean": np.nan,
                "shuffle_deltaG_sd": np.nan,
                "shuffle_deltaG_min": np.nan,
                "shuffle_deltaG_max": np.nan,
                "shuffle_z": np.nan,
                "shuffle_empirical_p": np.nan,
                "shuffle_note": "observed_deltaG_not_numeric"
            })
            continue

        if sname not in sno_seq_by_name:
            stats_rows.append({
                "snoRNA": sname,
                "target_enst": enst,
                "shuffle_n": 0,
                "shuffle_failures": n_shuffles,
                "shuffle_deltaG_mean": np.nan,
                "shuffle_deltaG_sd": np.nan,
                "shuffle_deltaG_min": np.nan,
                "shuffle_deltaG_max": np.nan,
                "shuffle_z": np.nan,
                "shuffle_empirical_p": np.nan,
                "shuffle_note": "missing_snoRNA_sequence"
            })
            continue

        sseq = sno_seq_by_name[sname]

        if enst not in tx_seq_cache:
            tx_seq_cache[enst] = load_transcript_sequence(fasta_path, enst)

        tx_seq = tx_seq_cache[enst]

        # Stable per-hit RNG for reproducibility.
        rng = random.Random(f"{seed}|{sname}|{enst}")

        bg_dGs = []
        failures = 0

        for j in range(n_shuffles):
            shuffled_sseq = shuffle_seq_mono(sseq, rng)

            try:
                (
                    bg_pos1_l,
                    bg_pos1_r,
                    bg_pos2_l,
                    bg_pos2_r,
                    bg_dbn,
                    bg_seq_total,
                    bg_dG
                ) = get_RNA_plex_output(
                    tx_seq,
                    shuffled_sseq,
                    l=l,
                    c=c,
                    return_energy=True
                )

                bg_dG = float(bg_dG)
                bg_dGs.append(bg_dG)

                if out_long_csv is not None:
                    long_rows.append({
                        "snoRNA": sname,
                        "target_gene": gene,
                        "target_enst": enst,
                        "shuffle_i": j + 1,
                        "shuffle_deltaG": bg_dG,
                        "shuffle_pos1_l": bg_pos1_l,
                        "shuffle_pos1_r": bg_pos1_r,
                        "shuffle_pos2_l": bg_pos2_l,
                        "shuffle_pos2_r": bg_pos2_r,
                        "shuffle_duplex_dbn": bg_dbn,
                        "shuffle_duplex_seq": bg_seq_total,
                        "shuffled_sno_sequence": shuffled_sseq
                    })

            except Exception as e:
                failures += 1

                if out_long_csv is not None:
                    long_rows.append({
                        "snoRNA": sname,
                        "target_gene": gene,
                        "target_enst": enst,
                        "shuffle_i": j + 1,
                        "shuffle_deltaG": np.nan,
                        "error": str(e),
                        "shuffled_sno_sequence": shuffled_sseq
                    })

        arr = np.array(bg_dGs, dtype=float)

        if len(arr) == 0:
            mean_bg = np.nan
            sd_bg = np.nan
            min_bg = np.nan
            max_bg = np.nan
            z = np.nan
            emp_p = np.nan
            note = "all_shuffles_failed"
        else:
            mean_bg = float(np.mean(arr))
            sd_bg = float(np.std(arr, ddof=1)) if len(arr) > 1 else np.nan
            min_bg = float(np.min(arr))
            max_bg = float(np.max(arr))

            if sd_bg and not np.isnan(sd_bg) and sd_bg > 0:
                z = float((float(obs_dG) - mean_bg) / sd_bg)
            else:
                z = np.nan

            # One-sided empirical p:
            # shuffled ΔG <= observed ΔG means shuffled is as strong or stronger.
            emp_p = float((np.sum(arr <= float(obs_dG)) + 1) / (len(arr) + 1))
            note = "partial_shuffle_failures" if failures else ""

        stats_rows.append({
            "snoRNA": sname,
            "target_enst": enst,
            "shuffle_n": int(len(arr)),
            "shuffle_failures": int(failures),
            "shuffle_deltaG_mean": mean_bg,
            "shuffle_deltaG_sd": sd_bg,
            "shuffle_deltaG_min": min_bg,
            "shuffle_deltaG_max": max_bg,
            "shuffle_z": z,
            "shuffle_empirical_p": emp_p,
            "shuffle_note": note
        })

    stats_df = pd.DataFrame(stats_rows)

    if out_long_csv is not None:
        pd.DataFrame(long_rows).to_csv(out_long_csv, index=False)
        print(f"[SHUFFLE] Wrote long shuffled-control results: {out_long_csv}")

    out = df_top_pair.merge(
        stats_df,
        on=["snoRNA", "target_enst"],
        how="left"
    )

    return out



def run_pipeline():
    validate_configuration()
    # Remove only stale audit output from a prior successful/partial run.
    (Path(OUT_DIR) / "audit_skips.csv").unlink(missing_ok=True)
    gtf_df = parse_gtf(GTF_FILE)
    sno_df = load_sno_list_df(SNO_LIST, name_col=SNO_NAME_COLUMN, seq_col=SNO_SEQUENCE_COLUMN)

    gene_to_ensts = parse_gencode_subset_fasta_headers(FASTA_PATH)

    tx_with_cds = set(
        gtf_df.loc[
            gtf_df["feature_norm"] == "cds",
            "transcript_id"
        ].unique()
    )

    gene_to_ensts = {
        g: {e for e in es if e in tx_with_cds}
        for g, es in gene_to_ensts.items()
    }

    print(
        f"[FILTER] Transcripts with CDS in GTF: {len(tx_with_cds):,}; "
        f"targets after CDS filter: {sum(len(v) for v in gene_to_ensts.values()):,}"
    )

    gtf_tx = set(gtf_df["transcript_id"].unique())
    selected_tx = {e for es in gene_to_ensts.values() for e in es}
    missing_in_gtf = sorted(e for e in selected_tx if e not in gtf_tx)

    print(
        f"[CHECK] Selected ENSTs: {len(selected_tx)}; "
        f"missing in GTF: {len(missing_in_gtf)}"
    )

    df_all = screen_sno_vs_targets_df_fast(
        sno_df=sno_df,
        fasta_path=FASTA_PATH,
        gtf_df=gtf_df,
        gene_to_ensts_override=gene_to_ensts,
        n_transcripts_limit=N_TRANSCRIPTS_LIMIT,
        l=PLEX_L,
        c=PLEX_C,
        energy_max=ENERGY_MAX,
        duplex_maxlen=DUPLEX_MAXLEN,
        require_utrs=REQUIRE_UTRS,
        make_audit_csv=True
    )

    all_csv = Path(OUT_DIR) / "tm_screen_all_pairs.csv"
    df_all.to_csv(all_csv, index=False)
    print(f"[OUT] Wrote: {all_csv}  ({len(df_all)} rows)")

    audit_path = Path(OUT_DIR) / "audit_skips.csv"

    if audit_path.exists():
        audit_df = pd.read_csv(audit_path)

        if not audit_df.empty:
            print("[AUDIT] Reason counts:")
            print(audit_df["reason"].value_counts(dropna=False))


    # --------------------------------------------------------------------
    # 9) Region summaries and top-pair output
    # --------------------------------------------------------------------
    if df_all.empty or ("pass_filters" not in df_all.columns) or ("target_region_label" not in df_all.columns):
        print("[Region pies] No results to summarize: empty or missing required columns.")

    else:
        df_hits = df_all[
            df_all["pass_filters"]
            & df_all["target_region_label"].isin(allowed_regions)
        ].copy()

        if df_hits.empty:
            print("[Region pies] No passing, region-labeled hits to summarize.")

        else:
            df_hits["deltaG"] = pd.to_numeric(df_hits["deltaG"], errors="coerce")

            if DEDUP_EXACT_SITES:
                before = len(df_hits)
                df_hits = df_hits.drop_duplicates(
                    subset=[
                        "snoRNA",
                        "target_enst",
                        "pos1_l",
                        "pos1_r",
                        "target_region_label"
                    ]
                )
                print(f"[Region pies] De-duplicated exact sites: {before} -> {len(df_hits)}")

            # ------------------------------------------------------------
            # MODE A: site-level hits
            # ------------------------------------------------------------
            if DO_SITE_PIE:
                site_hits_csv = Path(OUT_DIR) / "site_hits.csv"
                site_summary_csv = Path(OUT_DIR) / "site_region_summary.csv"
                site_pie_png = Path(OUT_DIR) / "site_region_pie.png"

                df_hits.to_csv(site_hits_csv, index=False)
                print(f"[SITE] Wrote hits: {site_hits_csv}  (n={len(df_hits)})")

                site_summary = (
                    df_hits["target_region_label"]
                    .value_counts()
                    .rename_axis("region")
                    .reset_index(name="count")
                )

                site_summary["fraction"] = site_summary["count"] / site_summary["count"].sum()
                site_summary.to_csv(site_summary_csv, index=False)

                print(f"[SITE] Wrote summary: {site_summary_csv}")
                print(site_summary)

                fig, ax = plt.subplots()
                ax.pie(
                    site_summary["count"],
                    labels=site_summary["region"],
                    autopct="%1.1f%%",
                    startangle=90
                )
                ax.set_title(
                    f"Predicted binding by region — SITE mode "
                    f"(n={int(site_summary['count'].sum())})"
                )
                fig.savefig(site_pie_png, dpi=200, bbox_inches="tight")
                plt.close(fig)

                print(f"[SITE] Wrote pie: {site_pie_png}")

            # ------------------------------------------------------------
            # MODE B: top hit per snoRNA-transcript pair
            # ------------------------------------------------------------
            if DO_TOP_PAIR_PIE:
                top_hits_csv = Path(OUT_DIR) / "top_pair_hits.csv"
                top_summary_csv = Path(OUT_DIR) / "top_pair_region_summary.csv"
                top_pie_png = Path(OUT_DIR) / "top_pair_region_pie.png"

                df_top_pair = (
                    df_hits
                    .sort_values("deltaG")  # more negative first
                    .drop_duplicates(["snoRNA", "target_enst"], keep="first")
                )

                if DO_SHUFFLE_ZSCORE:
                    shuffle_long_csv = (
                        Path(OUT_DIR) / "top_pair_shuffled_controls.csv"
                        if SAVE_SHUFFLE_LONG
                        else None
                    )

                    df_top_pair = add_shuffle_zscores_to_top_pairs(
                        df_top_pair=df_top_pair,
                        sno_df=sno_df,
                        fasta_path=FASTA_PATH,
                        n_shuffles=N_SHUFFLES,
                        l=PLEX_L,
                        c=PLEX_C,
                        seed=SHUFFLE_SEED,
                        out_long_csv=shuffle_long_csv
                    )

                df_top_pair.to_csv(top_hits_csv, index=False)
                print(
                    f"[TOP-PAIR] Wrote hits with shuffled controls: "
                    f"{top_hits_csv}  (pairs={len(df_top_pair)})"
                )

                top_summary = (
                    df_top_pair["target_region_label"]
                    .value_counts()
                    .rename_axis("region")
                    .reset_index(name="count")
                )

                top_summary["fraction"] = top_summary["count"] / top_summary["count"].sum()
                top_summary.to_csv(top_summary_csv, index=False)

                print(f"[TOP-PAIR] Wrote summary: {top_summary_csv}")
                print(top_summary)

                fig, ax = plt.subplots()
                ax.pie(
                    top_summary["count"],
                    labels=top_summary["region"],
                    autopct="%1.1f%%",
                    startangle=90
                )
                ax.set_title(
                    "Predicted binding by region — TOP per "
                    f"(snoRNA, transcript) (n={int(top_summary['count'].sum())})"
                )
                fig.savefig(top_pie_png, dpi=200, bbox_inches="tight")
                plt.close(fig)

                print(f"[TOP-PAIR] Wrote pie: {top_pie_png}")
    (Path(OUT_DIR) / "run_settings.json").write_text(json.dumps({
        "FASTA_PATH": str(FASTA_PATH), "SNO_LIST": str(SNO_LIST), "GTF_FILE": str(GTF_FILE),
        "RNAplex_exec": str(RNAplex_exec), "PLEX_L": PLEX_L, "PLEX_C": PLEX_C,
        "ENERGY_MAX": ENERGY_MAX, "N_SHUFFLES": N_SHUFFLES,
        "DO_SHUFFLE_ZSCORE": DO_SHUFFLE_ZSCORE, "SHUFFLE_SEED": SHUFFLE_SEED,
        "REQUIRE_UTRS": REQUIRE_UTRS, "TOL_FRAC": TOL_FRAC,
        "CDS_region_includes_stop_codon": True
    }, indent=2))
    return df_all


if __name__ == "__main__":
    df_all = run_pipeline()
