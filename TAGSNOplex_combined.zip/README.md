# TAGSNOplex

TAGSNOplex predicts RNA duplexes between supplied TAG-snoRNA/query sequences and
mRNA transcripts using RNAplex. This standalone script combines the original
Chunk 1 and Chunk 2; no previous notebook cells or local helper modules are needed.

## Requirements

- Python 3.10 or later.
- Python packages in `requirements.txt`: numpy, pandas, matplotlib and openpyxl.
- The RNAplex executable from ViennaRNA, installed separately:
  [ViennaRNA downloads and installation](https://www.tbi.univie.ac.at/RNA/).
- Optional visualization only: Java and the
  [VARNA JAR](https://varna.lisn.upsaclay.fr/).

Install Python packages with:

```sh
python -m pip install -r requirements.txt
```

Installing Python packages alone does not install the external RNAplex binary.
Check that RNAplex is available:

```sh
RNAplex --version
```

If it is not on PATH, set `RNAplex_exec` to its full executable path in the script.
Java and VARNA are unnecessary unless you call `show_structure()`.

## Inputs

Arrange the files as follows:

```text
TAGSNOplex/
  TAGSNOplex_combined.py
  requirements.txt
  input/
    target_transcripts.fasta
    TAGsno_DBN.csv
    gencode.v49.annotation.gtf
```

`target_transcripts.fasta` contains the transcripts to screen, using GENCODE headers
or headers such as `>ENST:ENST00000372285.8 | Gene:CD40`. It can be a preselected
subset of a reference transcript FASTA. This combined script does not extract
transcripts from the supplementary workbook. Download the transcript FASTA and
GTF from the [same GENCODE annotation release](https://www.gencodegenes.org/human/).
A newer release can be used by editing the paths. Keep the transcript accession
versions and source release recorded; matching strips transcript version suffixes.

The sno-list CSV needs these columns by default:

```csv
gene_name,Sequence
example_TAG,ACGUACGUACGUACGUACGU
```

Names must identify the supplied queries uniquely. Use the real TAG/domain
sequences intended for the experiment. Dot-bracket columns are not used to
extract unpaired domains automatically. DNA-style T is converted to U; whitespace
is removed. Queries containing other characters are rejected. Identical sequences
under different names produce identical predictions.

Excel sno-lists are also supported (first sheet); change `SNO_LIST` to the Excel
path. Set `SNO_NAME_COLUMN` and `SNO_SEQUENCE_COLUMN` if headers differ. Export
Apple Numbers files to CSV first. Legacy `.xls` requires the additional xlrd
package; CSV or `.xlsx` is recommended.

## Run

Open a terminal in the TAGSNOplex folder, edit the configuration block at the top
of the script, then run:

```sh
python TAGSNOplex_combined.py
```

Alternatively open `TAGSNOplex_combined.ipynb` and run its single code cell, or
paste the `.py` contents into one notebook cell. Paths are relative to the current
working folder. Imported as a module, the file defines helpers without starting
an analysis; call `run_pipeline()` explicitly to run it.

Important settings:

- `PLEX_L = 40`: maximum interaction length passed to RNAplex.
- `PLEX_C = 0`: duplex extension cost, not accessibility-window length. Use 55 only
  when deliberately reproducing the older extension-penalized analysis.
- `ENERGY_MAX = -15.0`: retain deltaG strictly below this value.
- `DUPLEX_MAXLEN = 150`: maximum target-side nucleotide span.
- `REQUIRE_UTRS = True`: skip targets lacking either UTR.
- `TOL_FRAC = 0.0`: require exact agreement between spliced exon length and FASTA
  length. This is stricter than the original 25% tolerance.
- `DO_SHUFFLE_ZSCORE = True`, `N_SHUFFLES = 1000`: calculate shuffled backgrounds
  for retained snoRNA/transcript pairs. This can take considerable time.
- For an initial setup check, set `N_TRANSCRIPTS_LIMIT = 2` and
  `DO_SHUFFLE_ZSCORE = False`. Reset the limit before a full run.

## Outputs and interpretation

Results are written to `output/mrna_screen/` by default. Use a fresh output folder
for separate runs to avoid confusing files retained from an older run.

- `tm_screen_all_pairs.csv`: results/errors for audited target/query pairs.
- `audit_skips.csv`: skipped transcript annotations, when any occur.
- `site_hits.csv`, `site_region_summary.csv`, `site_region_pie.png`: passing hits
  and region summary when `DO_SITE_PIE` is enabled.
- `top_pair_hits.csv`, `top_pair_region_summary.csv`, `top_pair_region_pie.png`:
  one retained hit per query/transcript, when `DO_TOP_PAIR_PIE` is enabled.
- `top_pair_shuffled_controls.csv`: optional individual shuffled predictions.
- `run_settings.json`: key settings and input paths.

This version requests one RNAplex result per full-transcript/query call and uses
the final prediction line returned. With the default RNAplex invocation this is
the minimum-energy duplex. It does not enumerate all potential binding sites;
therefore the site and top-pair summaries normally contain the same interactions.
Region assignment uses the segment with the greatest overlap, so a boundary-
spanning duplex receives one label. CDS region labels include annotated terminal
stop-codon bases. The map is reconstructed from exon, CDS and stop-codon rows in
transcript order, including correct within-exon ordering on negative strands.

Shuffled controls preserve query length and mononucleotide composition, and rerun
RNAplex against the same full transcript with the same parameters. More negative
Z-scores indicate stronger binding relative to this background. Empirical p-values
use `(1 + controls_as_strong_or_stronger) / (1 + successful_controls)` and are
unadjusted for multiple testing. Background failures are recorded; partial-
failure results should be reviewed before interpretation. With only 25 controls,
the smallest possible empirical p-value is 1/26. The energy filter alone is not
a statistical significance call.

This workflow does not predict H/ACA-guided pseudouridylation, automatically model
RNA accessibility, translate CDS hits to amino acid positions, or select the top
three queries per gene. Those are separate analyses. The three-target CDS/residue
notebook is a different workflow.

## Validation

The merged script was checked with synthetic inputs for positive/negative strand
mapping, stop-codon handling, strict length auditing, RNAplex output parsing,
shuffled-control calculations, and CSV/report generation. A stand-in executable
was used to exercise the RNAplex interface; actual biological predictions and
VARNA rendering were not run during these checks.
